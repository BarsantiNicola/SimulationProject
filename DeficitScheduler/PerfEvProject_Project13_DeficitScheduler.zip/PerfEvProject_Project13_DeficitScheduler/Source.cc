//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Source.h"

Define_Module(Source);

void Source::initialize()
{
    EV << "Source -- Initializing" << endl;
    //starting the "Source": setting a timer which notifies the "Source" when it's time to send the first "Job" to the "Server"
    startTimer();
}

void Source::handleMessage(cMessage *msg)
{
    /*  This function is called when a "timeout" message (which is "msg") arrives, hence a "timeoutEvent" has occurred.
        This means that it's time to send a new "Job" to the "Server". */

    //creating a new "Job" and sending it to the "Server"
    produce();

    //setting a timer to notify the "Source" when it's time to send the next "Job" to the "Server"
    startTimer();
}

void Source::startTimer()
{
    //This function sets a timer which notifies the "Source" when it's time to send a new "Job" to the "Server"

    if((bool) par("isDeterministic")) scheduleAt(simTime() + (simtime_t) par("interarrivalTime"), timeoutEvent);
    else scheduleAt(simTime() + exponential((simtime_t) par("interarrivalTime"), (int) par("interarrivalTimeRngId")), timeoutEvent);
}

void Source::produce()
{
    //This function creates a new "Job" and sends it to the "Server"

    Job * j = new Job("job");
    j -> setId(jobCounter);
    jobCounter++;
    j -> setCreationTime(simTime());
    //setting the service time properly
    if((bool) par("isDeterministic")) j -> setServiceTime((simtime_t) par("serviceTime"));
    else j -> setServiceTime(exponential((simtime_t) par("serviceTime"), (int) par("serviceTimeRngId")));
    EV << "Source -- New job produced at time " << simTime() << endl;
    printJob(j);
    send(j, "out");
}


void Source::printJob(Job* j)
{
    EV << "Source -- Name: " << j -> getName() << endl;
    EV << "Source -- Id: " << j -> getId() << endl;
    EV << "Source -- Creation time: " << j -> getCreationTime() << endl;
    EV << "Source -- Service time: " << j -> getServiceTime() << endl;
}
