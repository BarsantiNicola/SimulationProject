//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Server.h"

Define_Module(Server);

void Server::initialize()
{
    EV << "Server -- Initializing" << endl;
    jobsInSystem = registerSignal("jobsInSystem");
    responseTime = registerSignal("responseTime");
    emit(jobsInSystem, (unsigned long) 0);
    //at the beginning the queue is empty, therefore the server is on vacation
    startVacation();
}

void Server::handleMessage(cMessage *msg)
{
    if(msg -> isName("job")){ //new job arrived, enqueueing it
        enqueueJob(check_and_cast<Job*>(msg));
    }

    if(msg -> isName("endVacation")){ //vacation finished
        endVacation();
    }

    if(msg -> isName("jobCompleted")){ //job completed
        //removing the job from the queue
        finalizeCurrentJob();

        //starting a new job (if it's possible) or going on vacation
        if(cantStartNextJob()) startVacation();
        else executeNextJob();
    }
}

void Server::startVacation()
{
    //setting parameters according to the scheduling policy
    if(jobs.empty()) d = 0;
    else d = q;

    //preparing a timer to notify the end of the vacation
    simtime_t vacationTime;
    if((bool) par("isDeterministic")) vacationTime = (simtime_t) par("vacationTime");
    else vacationTime = exponential( (simtime_t) par("vacationTime"), (int) par("vacationTimeRngId"));
    EV << "Server -- Starting a vacation from time " << simTime() << " to time " << simTime() + vacationTime << endl;
    printQueueStatus();
    EV << "Server -- Deficit was set to " << d << endl;
    if(!jobs.empty()) EV << "Server -- Next job service time is " << jobs.front() -> getServiceTime() << endl;
    scheduleAt(simTime() + vacationTime, endVacationEvent);
}

void Server::endVacation()
{
    //setting parameters according to the scheduling policy
    q = d + (simtime_t) par("Q");
    EV << "Server -- Vacation finished at time " << simTime() << endl;
    printQueueStatus();
    EV << "Server -- The expected duration of next turn was set to " << q << endl;
    if(!jobs.empty()) EV << "Server -- Next job service time is " << jobs.front() -> getServiceTime() << endl;

    //starting a new job (if it's possible) or going on vacation again
    if(cantStartNextJob()) startVacation();
    else executeNextJob();
}

void Server::enqueueJob(Job* j)
{
    EV << "Server -- New job arrived at time " << simTime() << endl;
    printJob(j);
    jobs.push(j);
    printQueueStatus();

    emit(jobsInSystem, (unsigned long) (jobs.size() + (currentJob == nullptr ? 0 : 1)));
}

void Server::executeNextJob()
{
    //setting parameters according to the scheduling policy
    currentJob = jobs.front();
    jobs.pop();
    EV << "Server -- Starting the execution of a new job at time " << simTime() << endl;
    EV << "Server -- Remaining time until the end of the turn: " << q << endl;
    EV << "Server -- Next job service time: " << currentJob -> getServiceTime() << endl;
    EV << "Server -- Next job description: " <<endl;
    printJob(currentJob);

    //preparing a timer to notify the completion of the job
    scheduleAt(simTime() + currentJob -> getServiceTime(), jobCompletedEvent);
}

void Server::finalizeCurrentJob()
{
    //a job has been completed, removing it from the queue

    EV << "Server -- Job completed at time " << simTime() << endl;
    EV << "Server -- Job description: " << endl;
    printJob(currentJob);
    simtime_t respTime = simTime() - currentJob -> getCreationTime();
    EV << "Server -- Job fulfilling time: " << respTime << endl;
    //setting parameters according to the scheduling policy
    q -= currentJob -> getServiceTime();
    EV << "Server -- Remaining time until the end of the turn: " << q << endl;
    //deleting the job
    delete currentJob;
    currentJob = nullptr;
    printQueueStatus();
    emit(jobsInSystem, jobs.size());
    emit(responseTime, respTime);
}

bool Server::cantStartNextJob()
{
    //can't start next job because there are no more jobs in queue or next job can't be completed within the end of the turn
    return jobs.empty() || jobs.front() -> getServiceTime() > q;
}

void Server::printJob(Job* j)

{
    EV << "Server -- Name: " << j -> getName() << endl;
    EV << "Server -- Id: " << j -> getId() << endl;
    EV << "Server -- Creation time: " << j -> getCreationTime() << endl;
    EV << "Server -- Service time: " << j -> getServiceTime() << endl;
}

void Server::printQueueStatus()
{
    EV << "Server -- Status of the queue at time " << simTime() << ": " << jobs.size() << " elements" << endl;
}

Server::~Server(){
    // flushing the remaining elements in queue
    if(currentJob != nullptr) delete currentJob;
    while(!jobs.empty()){
        currentJob = jobs.front();
        jobs.pop();
        delete currentJob;
    }
    cancelAndDelete(endVacationEvent);
    cancelAndDelete(jobCompletedEvent);
}
